use strict;
use warnings;

print "하나";

BEGIN {
    print "둘";
}

print "셋";
# 둘하나셋