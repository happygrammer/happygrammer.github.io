# 배열 타입 : Python의 list, PHP의 array에 해당하는 타입
my @array = (
	"one",
	"two",
	"three", # trailing 컴마 허용
);
print "배열 요소는 ".(scalar @array)."개\r\n"; # "배열 요소는 3개"
print "배열 요소는 @array\r\n"; # "배열 요소는 one two three"
print $array[0]; # "one"
print $array[1]; # "two"
print $array[2]; # "three"