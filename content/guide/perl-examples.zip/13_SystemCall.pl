my $rc = system "perl", "1_Helloworld.pl"; # Hello World
print $rc; # 0 => 프로세스의 status word를 출력함

my $result = qx("ping localhost"); # 명령어 실행 결과를 변수에 저장
print $result; # 캡쳐 결과 출력