# Scala 변수 : undef, number(int, float), string, 참조 변수
my $undef = undef;
print $undef; # 빈 문자열(" ")을 출력함

my $undef2; # implicit undef 선언
print $undef2;

my $num = 100;
print $num; # "100"을 출력함

my $string = "hello\r\n";
print $string; # "hello"를 출력함

# Boolean 타입 : Boolean 타입은 없으며 undef, number 0, string "" string "0" 인지를 if 조건 문에서 검사해야함