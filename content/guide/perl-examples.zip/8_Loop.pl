my @array = (
	"one",
	"two",
	"three"
);

my $i = 0;
while($i < scalar @array) {
	print $i, ": ", $array[$i]; # 0: one1: two2: three
	$i++;
}

print "\n";

foreach my $i ( 0 .. $#array ) {
	print $i, ": ", $array[$i]; # 0: one1: two2: three
}

print "\n";

for(my $i = 0; $i < scalar @array; $i++) {
	print $i, ": ", $array[$i]; # 0: one1: two2: three
}