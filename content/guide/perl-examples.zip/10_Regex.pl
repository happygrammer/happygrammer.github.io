# Match 처리
my $string = "Hello world";
if($string =~ m/(\w+)\s+(\w+)/) { # success 
	print "success";
}

# Replace 처리
my $string = "One Two Three";
$string =~ s/Two/2/;
print $string; # "One 2 Three"