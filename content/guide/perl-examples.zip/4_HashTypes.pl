# 해쉬 타입 : Python의 Dict, PHP의 array에 해당하는 타입
my %hashValues = (
	"1"   => "One",
	"2" => "Two",
	"3"   => "Trhee",
);

print $hashValues{"One"};   # "One"
print $hashValues{"Two"};   # "Two"
print $hashValues{"Trhee"};   # "Trhee"