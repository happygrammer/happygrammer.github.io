#!/usr/bin/perl
use strict;
use warnings;

opendir(dirHandle, "." ) or die "$!\n";
my @items = readdir(dirHandle);  # @items에 파일 목록 할당
closedir dirHandle;

foreach (@items) {
    next if $_ =~ /^\.\.?$/; # . or .. 이면 Skip
    next unless (-f $_);     # 디렉터리 이면 Skip
    print $_, "\n"; # 파일명 이면 출력
}