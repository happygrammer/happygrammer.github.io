my @outer = ("Sun", "Mercury", "Venus", undef, "Mars");
my @inner = ("Earth", "Moon");

$outer[3] = @inner; # @inner는 scala 변수로 취급되어 2가 할당됨
print $outer[3]; # "2"

$outer[3] = "Earth"; # Earth가 할당됨
print $outer[3]; # "Earth"