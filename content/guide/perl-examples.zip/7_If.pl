my $abc = "abcdefg";
my $strlen = length $abc;

if($strlen >= 3) {
	print "'", $abc, "'는 3글자 이상";
} elsif(1 <= $strlen && $strlen < 3) {
	print "'", $abc, "'는 1~2글자";
} else {
	print "'", $abc, "'는 1글자 이하";
}