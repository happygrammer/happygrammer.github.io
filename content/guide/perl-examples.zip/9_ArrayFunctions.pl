my @array = (
	"one",
	"two",
	"three"
);

print join(", ", @array); # one, two, three => Array 요소를 , 로 구분해 합치기
print "\r\n";
print reverse(@array); # threetwoone => Array 요소를 뒤집기
print "\r\n";
print join(", ", reverse(@array)); # three, two, one => Array 요소를 뒤집어 , 로 구분해 합치기