use strict;
use warnings;

print "Hello world";  # ; 를 붙여야함에 유의