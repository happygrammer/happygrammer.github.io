my $hello    = "Hello";
my $helloRef = \$hello;

print $hello."\r\n";         # "Hello" => 할달됭 값 출력
print $helloRef."\r\n";      # "SCALAR(0x2525dd0)" => 참조 주소 출력
print ${ $helloRef }."\r\n"; # "Hello" => 참조하는 값 출력
print $$helloRef # "Hello" => 참조하는 값 출력