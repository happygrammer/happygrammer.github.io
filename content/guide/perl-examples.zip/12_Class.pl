package Hello;

use strict;
use warnings;

# 생성자
sub new {
    my ($class, %args) = @_;
    return bless { %args }, $class;
}

# Hello 클래스의 메서드
sub helloWorld {
    my ($self) = @_;
    print $self->{data1}." ";
    print $self->{data2};
}

my $helloObject = Hello->new( data1 => 'hello',
                      data2 => 'world' );
$helloObject->helloWorld(); # hello world